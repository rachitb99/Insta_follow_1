python3 main.py we_are_slick
JSON=y
followers
exit
