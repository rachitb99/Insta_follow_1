import random
import time
from bs4 import BeautifulSoup
import requests
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
import os
directory = 'accounts'

existing = []

for filename in os.listdir(directory):
    existing.append(filename)

f2 = open("followed.csv", "r")
followed = f2.read().split('\n')
f2.close()


followed = [x.split('|') for x in followed if x!='']

followed = [x[0] for x in followed if x[1] == '1']

to_get_followers = [x for x in followed if x not in existing]

username = "confessionsnow2022"
password = "MLAconfess@"

for account in to_get_followers:
  os.system('cd Osintgram')
  os.system("make setup")
  os.system(username)
  os.system(password)
  os.system("python3 Osintgram/main.py " + account + " & JSON=y & followers")
  break

