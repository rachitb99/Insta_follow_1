add 10 csv to accounts
10 accounts to followed
run main.py script
run follow.py script

empty account folder

run get_followers.py script
